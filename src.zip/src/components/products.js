import React from "react";
import "./products.css";

function Products() {
  return (
    <div className="products">
      <div className="purpose" style={{ marginTop: "40px" }}>
        <div className="purposeSub">
          <div className="purposeItems purposeItem1 text-start">
            <h2 className="fw-bold">One Stop Solution for Your Supply Chain</h2>
            <span>
              Connected Shipping, Finance, and Trade-tech, to Power Global Trade
              and Supply Chains.
            </span>
          </div>
          <div className="purposeItems purposeItem2">
            <img
              alt="Product"
              src="https://www.cogoport.com/_next/image?url=https%3A%2F%2Fcdn.cogoport.io%2Fcms-prod%2Fcogo_public%2Fvault%2Foriginal%2Fmap-supply-chain.png&w=384&q=75"
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default Products;
