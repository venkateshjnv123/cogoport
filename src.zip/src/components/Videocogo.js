import React, { Component } from 'react'

export default function Videocogo(){
    return(
        <div className='Videocogo'>
            <div className='videocogosub'>
                
            </div>
        </div>
    )
}