import logo from './logo.svg';
import './App.css';
import NavbarMain from './components/Navbar';
import Homepage from './components/MainPage';
import HowItWorks from './components/HowItWorks';
import Industries from './components/Industries';
import TrustedBy from './components/TrustedBy';
import Products from './components/products';
import GetStarted from './components/Getstartedtoday';

function App() {
  return (
    <div className="App">
     <NavbarMain/>
     <GetStarted/>
     <Products/>
     <Homepage/>
     <HowItWorks/>
     <Industries/>
    </div>
  );
}

export default App;
